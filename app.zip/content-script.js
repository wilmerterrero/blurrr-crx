const c="blurrr",x="blurrr_menu",d="blurrr_menu_content",k="blurrr_menu_stop",$="blurrr_menu_remove_all",E="blurrr_menu_donate",M="blurrr_menu_feedback",l="#3C4043",b="#EA4B3A",w="@wilterrero",B=`
<style>
    :host {
        all: initial;
        position: fixed;
        top: 90%;
        left: 50%;
        width: 350px !important;
        height: auto !important;
        transform: translate(-50%, -50%);
        background-color: white;
        border-radius: 5px;
        box-shadow: 0 0 30px rgba(0, 0, 0, 0.25);
        z-index: 1001;
        font-family: sans-serif;
    }
    #${d} {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    #${d} > div {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        gap: 20px;
        padding: 10px;
    }
    button {
        background: none !important;
        color: inherit !important;
        border: none !important;
        padding: 0 !important;
        font: inherit !important;
        cursor: pointer !important;
        outline: inherit !important;
        margin-top: 10px !important;
    }
    p {
        margin: 10px 0 !important;
        padding: 0 !important;
        font-size: 12px !important;
        font-weight: 500 !important;
        text-align: center !important;
    }
    label {
        padding: 0 !important;
        font-size: 12px !important;
        font-weight: 600 !important;
        text-align: center !important;
        color: ${l} !important;
        display: block;
    }
    span {
        margin-bottom: 10px !important;
        padding: 0 !important;
        font-size: 12px !important;
        font-weight: 500 !important;
        text-align: center !important;
    }
</style>
<div id="${x}">
  <div id="${d}">
    <div>
      <button type="button" id="${k}">
        ${`<svg xmlns="http://www.w3.org/2000/svg" style="width: 20px; height: 20px; color: ${l};" fill="${l}" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M17 4h-10a3 3 0 0 0 -3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3 -3v-10a3 3 0 0 0 -3 -3z" stroke-width="0" fill="currentColor" /></svg>`}
        <label>Stop</label>
      </button>
      <button type="button" id="${M}">
        ${`<svg xmlns="http://www.w3.org/2000/svg" style="width: 20px; height: 20px; color: ${l};" fill="${l}" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M8 9h8" /><path d="M8 13h6" /><path d="M13 18l-5 3v-3h-2a3 3 0 0 1 -3 -3v-8a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v6" /><path d="M16 22l5 -5" /><path d="M21 21.5v-4.5h-4.5" /></svg>`}
        <label>Feedback/Bug</label>
      </button>
      <button type="button" id="${E}">
        ${`<svg xmlns="http://www.w3.org/2000/svg" style="width: 20px; height: 20px; color: ${l};" fill="${l}" width="24" height="24" viewBox="0 0 24 24"><path d="M17.726 13.02 14 16H9v-1h4.065a.5.5 0 0 0 .416-.777l-.888-1.332A1.995 1.995 0 0 0 10.93 12H3a1 1 0 0 0-1 1v6a2 2 0 0 0 2 2h9.639a3 3 0 0 0 2.258-1.024L22 13l-1.452-.484a2.998 2.998 0 0 0-2.822.504zm1.532-5.63c.451-.465.73-1.108.73-1.818s-.279-1.353-.73-1.818A2.447 2.447 0 0 0 17.494 3S16.25 2.997 15 4.286C13.75 2.997 12.506 3 12.506 3a2.45 2.45 0 0 0-1.764.753c-.451.466-.73 1.108-.73 1.818s.279 1.354.73 1.818L15 12l4.258-4.61z"/></svg>`}
        <label>Donate</label>
      </button>
      <button type="button" id="${$}">
        ${`<svg xmlns="http://www.w3.org/2000/svg" style="width: 20px; height: 20px; color: ${b};" fill="${b}" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 7l16 0" /><path d="M10 11l0 6" /><path d="M14 11l0 6" /><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" /><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" /></svg>`}
        <label>Remove all</label>
      </button>
    </div>
    <p>
      Click on the elements you want to blur. 
    </p>
    <span>Made by <a href="https://twitter.com/${w}" target="_blank">${w}</a></span>
  </div>
</div>
`;let s=!1;function S(t){(function(e,i){let n=e;for(;n;){if(n.id===i)return!0;n=n.parentElement}return!1})(t.target,c)||(t.preventDefault(),t.stopPropagation(),function(e){s&&(e.style.filter!=="blur(8px)"?(e.style.filter="blur(8px)",function(i){const n=L(i),r=window.location.origin,o=JSON.parse(localStorage.getItem("blurredElements"))||{};o[r]||(o[r]=[]),o[r].push(n),localStorage.setItem("blurredElements",JSON.stringify(o))}(e)):(e.style.filter="",_(e)))}(t.target))}function v(){s=!1,document.getElementById(c).remove(),document.removeEventListener("click",S,!0)}function y(t){const e=document.createElement("a");e.setAttribute("href",t),e.setAttribute("target","_blank"),e.click(),e.remove()}function _(t){const e=L(t),i=window.location.origin,n=JSON.parse(localStorage.getItem("blurredElements"))||{};n[i]&&(n[i]=n[i].filter(r=>r!==e),localStorage.setItem("blurredElements",JSON.stringify(n)))}function L(t,e=5){var i;if(t.dataset&&Object.keys(t.dataset).length>0){const[n,r]=Object.entries(t.dataset)[0];return`${t.tagName.toLowerCase()}[data-${n}="${r}"]`}if(t.id)return`#${t.id}`;if(t.src)return`img[src="${t.src}"]`;if(t.href)return`a[href="${t.href}"]`;if(t.title)return`*[title="${t.title}"]`;{let n=[],r=0;for(;t&&r<e;){let o=t.tagName.toLowerCase();o+=`:nth-of-type(${Array.prototype.indexOf.call(((i=t.parentNode)==null?void 0:i.children)||[],t)+1})`,n.unshift(o),t=t.parentElement,r++}return n.join(" > ")}}chrome.runtime.onMessage.addListener(function(t,e,i){if(t.action==="toggleBlur")if(s=!s,s){const n=document.createElement("div");n.id=c,document.body.appendChild(n);const r=n.attachShadow({mode:"open"});r.innerHTML=B,document.addEventListener("click",S,!0);const o=r.getElementById(k),p=r.getElementById($),u=r.getElementById(M),h=r.getElementById(E);o&&o.addEventListener("click",function(){v()}),p&&p.addEventListener("click",function(){(function(){const m=window.location.origin,g=JSON.parse(localStorage.getItem("blurredElements"))||{};g[m]&&g[m].forEach(f=>{try{const a=document.querySelector(f);a&&(a.style.filter="",_(a))}catch(a){console.error("Error removing blur from selector:",f,a)}})})()}),u&&u.addEventListener("click",function(){y("https://tally.so/r/3EWP74")}),h&&h.addEventListener("click",function(){y("https://www.buymeacoffee.com/wilmerterrero")})}else v()});new MutationObserver(t=>{t.forEach(e=>{e.addedNodes.length&&function(){const i=window.location.origin,n=JSON.parse(localStorage.getItem("blurredElements"))||{};n[i]&&n[i].forEach(r=>{try{const o=document.querySelector(r);o&&(o.style.filter="blur(8px)")}catch(o){console.error(`${x}: Error applying blur to selector:`,r,o)}})}()})}).observe(document.body,{childList:!0,subtree:!0});
