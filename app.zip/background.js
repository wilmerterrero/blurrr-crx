chrome.action.onClicked.addListener(e=>{e.url!=="chrome://extensions/"&&e.id&&chrome.tabs.query({active:!0,currentWindow:!0},function(n){chrome.tabs.sendMessage(e.id,{action:"toggleBlur"})})});
